// Handle waste report submission
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("reportForm");

    if (form) {
        form.addEventListener("submit", (e) => {
            e.preventDefault();

            const report = {
                location: form.querySelector("input").value,
                type: form.querySelector("select").value,
                description: form.querySelector("textarea").value,
                status: "Pending",
                date: new Date().toLocaleDateString()
            };

            let reports = JSON.parse(localStorage.getItem("reports")) || [];
            reports.push(report);
            localStorage.setItem("reports", JSON.stringify(reports));

            alert("Waste report submitted successfully!");
            form.reset();
        });
    }
});

// Display reports on dashboard
document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("reportsContainer");

    if (container) {
        const reports = JSON.parse(localStorage.getItem("reports")) || [];

        if (reports.length === 0) {
            container.innerHTML = "<p class='text-muted'>No reports submitted yet.</p>";
            return;
        }

        reports.forEach(report => {
            const badgeClass = report.status === "Resolved" ? "bg-success" : "bg-warning";

            container.innerHTML += `
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <span class="badge ${badgeClass} mb-2">${report.status}</span>
                            <h5 class="card-title">${report.type}</h5>
                            <p class="card-text">${report.description}</p>
                            <small class="text-muted">${report.location} • ${report.date}</small>
                        </div>
                    </div>
                </div>
            `;
        });
    }
});





document.addEventListener("DOMContentLoaded", () => {

    // SAVE REPORT
    const reportForm = document.getElementById("reportForm");

    if (reportForm) {
        reportForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const report = {
                location: document.getElementById("location").value,
                type: document.getElementById("type").value,
                description: document.getElementById("description").value,
                status: "Pending",
                date: new Date().toLocaleDateString()
            };

            const reports = JSON.parse(localStorage.getItem("reports")) || [];
            reports.push(report);
            localStorage.setItem("reports", JSON.stringify(reports));

            alert("Waste report submitted successfully!");
            reportForm.reset();
        });
    }

    // DISPLAY REPORTS
    const container = document.getElementById("reportsContainer");

    if (container) {
        const reports = JSON.parse(localStorage.getItem("reports")) || [];

        if (reports.length === 0) {
            container.innerHTML = "<p class='text-muted'>No reports submitted yet.</p>";
            return;
        }

        reports.forEach(report => {
            const badgeClass = report.status === "Resolved"
                ? "bg-success"
                : "bg-warning text-dark";

            container.innerHTML += `
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <span class="badge ${badgeClass} mb-2">${report.status}</span>
                            <h5 class="card-title">${report.type}</h5>
                            <p class="card-text">${report.description}</p>
                            <small class="text-muted">${report.location} • ${report.date}</small>
                        </div>
                    </div>
                </div>
            `;
        });
    }

});

// DISPLAY REPORTS table 

// DISPLAY REPORTS IN TABLE
const tableBody = document.getElementById("reportsTableBody");

if (tableBody) {
    const reports = JSON.parse(localStorage.getItem("reports")) || [];

    if (reports.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted">
                    No reports submitted yet.
                </td>
            </tr>
        `;
    } else {
        reports.forEach((report, index) => {
            const statusBadge =
                report.status === "Resolved"
                    ? "<span class='badge bg-success'>Resolved</span>"
                    : "<span class='badge bg-warning text-dark'>Pending</span>";

            tableBody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${report.location}</td>
                    <td>${report.type}</td>
                    <td>${report.description}</td>
                    <td>${report.date}</td>
                    <td>${statusBadge}</td>
                </tr>
            `;
        });
    }
}

